import React from "react";

const Header = ({ logo, navLinks, userAction }) => {
  return (
    <header className="header">
      <div className="logo">{logo}</div>
      <nav>
        <ul className="nav-links">
          {navLinks.map((link, index) => (
            <li key={index}>
              <a href={link.href}>{link.label}</a>
            </li>
          ))}
        </ul>
      </nav>
      <div className="user-action">{userAction}</div>
    </header>
  );
};

export default Header;
