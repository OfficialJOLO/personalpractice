import React from "react";

const Footer = ({ copyright, links }) => {
  return (
    <footer className="footer">
      <div className="footer-links">
        {links.map((link, index) => (
          <a key={index} href={link.href}>
            {link.label}
          </a>
        ))}
      </div>
      <div className="footer-copyright">{copyright}</div>
    </footer>
  );
};

export default Footer;
