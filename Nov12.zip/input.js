import React from "react";
import PropTypes from "prop-types";

const Input = ({
  type = "text",
  value,
  onChange,
  placeholder = "",
  className = "",
  style = {},
  disabled = false,
}) => {
  return (
    <input
      type={type}
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      className={`input ${className}`}
      style={style}
      disabled={disabled}
    />
  );
};

Input.propTypes = {
  type: PropTypes.oneOf(["text", "password", "email", "number", "tel"]),
  value: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired,
  placeholder: PropTypes.string,
  className: PropTypes.string,
  style: PropTypes.object,
  disabled: PropTypes.bool,
};

export default Input;
