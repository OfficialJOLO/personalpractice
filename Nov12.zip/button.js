import React from "react";
import PropTypes from "prop-types";

const Button = ({
  label,
  onClick,
  type = "button",
  className = "",
  disabled = false,
  style = {},
}) => {
  return (
    <button
      type={type}
      className={`button ${className}`}
      onClick={onClick}
      disabled={disabled}
      style={style}
    >
      {label}
    </button>
  );
};

Button.propTypes = {
  label: PropTypes.string.isRequired,
  onClick: PropTypes.func.isRequired,
  type: PropTypes.oneOf(["button", "submit", "reset"]),
  className: PropTypes.string,
  disabled: PropTypes.bool,
  style: PropTypes.object,
};

export default Button;
