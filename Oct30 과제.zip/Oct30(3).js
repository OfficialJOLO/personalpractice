// 조건부 렌더링
function ValidUserChecking() {
  const isHuman = true;
  return <h1>{isHuman ? "Identified!!" : "Check whether you're human."}</h1>;
}

export default ValidUserChecking;
