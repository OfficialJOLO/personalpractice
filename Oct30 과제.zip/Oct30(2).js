// 부모요소로 감싸기

function App() {
  return (
    <div>
      <h1>Welcome to Jinyong's Page</h1>
      <p>Hello World!</p>
    </div>
  );
}

export default App;
