import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "내 API 키",
  authDomain: "내 관리자 도메인",
  projectId: "내 프로젝트 ID",
  storageBucket: "스토리지 버킷",
  messagingSenderId: "센더 ID",
  appId: "앱ID",
};

// Firebase 앱 초기화
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
