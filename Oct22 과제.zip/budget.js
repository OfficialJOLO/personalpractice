let totalAssets = 0;
const expenseList = [];

document.getElementById("saveAssetsBtn").addEventListener("click", () => {
  totalAssets = parseFloat(document.getElementById("totalAssets").value);
  document.getElementById("totalAssets").value = "";
});

document.getElementById("addExpenseBtn").addEventListener("click", () => {
  const category = document.getElementById("category").value;
  const description = document.getElementById("description").value;
  const amount = parseFloat(document.getElementById("amount").value);

  if (
    category &&
    description &&
    !isNaN(amount) &&
    amount > 0 &&
    amount <= totalAssets
  ) {
    const expense = {
      category,
      description,
      amount,
      time: new Date(),
    };
    expenseList.push(expense);
    updateExpenseList();
    document.getElementById("category").value = "";
    document.getElementById("description").value = "";
    document.getElementById("amount").value = "";
  } else {
    alert("모든 내용을 입력하고, 소비 금액은 현재 자산 이하로 입력.");
  }
});

function updateExpenseList() {
  const list = document.getElementById("expenseList");
  list.innerHTML = "";
  expenseList.sort((a, b) => a.time - b.time);
  expenseList.forEach((expense, index) => {
    const item = document.createElement("li");
    item.textContent = `${expense.category}: ${expense.description} - ${
      expense.amount
    }원 (${formatTime(expense.time)})`;

    const deleteBtn = document.createElement("button");
    deleteBtn.textContent = "삭제";
    deleteBtn.addEventListener("click", () => {
      expenseList.splice(index, 1);
      updateExpenseList();
    });

    item.appendChild(deleteBtn);
    list.appendChild(item);
  });
}

function formatTime(date) {
  const hours = String(date.getHours()).padStart(2, "0");
  const minutes = String(date.getMinutes()).padStart(2, "0");
  return `${hours}:${minutes}`;
}
